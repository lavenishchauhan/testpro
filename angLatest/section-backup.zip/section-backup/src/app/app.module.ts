import { CartService } from './services/cart.service';
import { AppErrorHandler } from './common/validators/app-error-handler';
import { AuthService } from './services/auth.service';
import { NotFoundComponent } from './not-found/not-found.component';
import { AuthGuard } from './services/auth-guard.service';
import { AdminAuthGuard } from './services/admin-auth-guard.service';
import { NoAccessComponent } from './no-access/no-access.component';
import { MaterialModule } from './material/material.module';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule, ErrorHandler } from '@angular/core';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AdminOrdersComponent } from './admin/admin-orders/admin-orders.component';
import { AdminProductsComponent } from './admin/admin-products/admin-products.component';
import { ShoppingCartComponent } from './shopping-cart/shopping-cart.component';
import { ProductsComponent } from './products/products.component';
import { OrderSuccessComponent } from './order-success/order-success.component';
import { MyOrdersComponent } from './my-orders/my-orders.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { HomeComponent } from './home/home.component';
import { CheckOutComponent } from './check-out/check-out.component';
import { BsNavbarComponent } from './bs-navbar/bs-navbar.component';
import { RouterModule } from '@angular/router';
import { ServerRequestService } from './services/server-request.service';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { TokenInterceptorService } from './services/token-interceptor.service';
import { FormsModule } from '@angular/forms';
import { ProductFormComponent } from './admin/product-form/product-form.component';
import { ProductFilterComponent } from './products/product-filter/product-filter.component';
import { ProductCardComponent } from './product-card/product-card.component';
import { TotalItemsCountComponent } from './total-items-count/total-items-count.component';
import { InputFormatDirective } from './directive/input-format.directive';




@NgModule({
  declarations: [
    AppComponent,
    AdminOrdersComponent,
    AdminProductsComponent,
    ShoppingCartComponent,
    ProductsComponent,
    OrderSuccessComponent,
    MyOrdersComponent,
    LoginComponent,
    HomeComponent,
    CheckOutComponent,
    BsNavbarComponent,
    RegisterComponent,
    NoAccessComponent,
    NotFoundComponent,
    ProductFormComponent,
    ProductFilterComponent,
    ProductCardComponent,
    TotalItemsCountComponent,
    InputFormatDirective
  ],
  imports: [
    BrowserModule,
    NgbModule,
    BrowserAnimationsModule,
    MaterialModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot([
      {
        path: '',
        component: ProductsComponent
      },
      {
        path: 'admin',
        component: AdminOrdersComponent,
        canActivate: [AuthGuard, AdminAuthGuard]
      },

      
      {
        path: 'admin/products',
        component: AdminProductsComponent,
        canActivate: [AuthGuard, AdminAuthGuard]
      },
      {
        path: 'admin/products/new',
        component: ProductFormComponent,
        canActivate: [AuthGuard, AdminAuthGuard]
      },

      {
        path: 'admin/products/:_id',
        component: ProductFormComponent,
        canActivate: [AuthGuard, AdminAuthGuard]
      },

      { path: 'shoppingcart', component: ShoppingCartComponent },
  

      { path: 'register', component: RegisterComponent },
      { path: 'login', component: LoginComponent },

      { path: 'no-access', component: NoAccessComponent },
      {
        path: '**',
        component: NotFoundComponent
      }
    ])
  ],
  providers: [
    ServerRequestService,
     {provide: ErrorHandler, useClass: AppErrorHandler},
    AuthService,
    AuthGuard,
    AdminAuthGuard,
    CartService,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: TokenInterceptorService,
      multi: true
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
