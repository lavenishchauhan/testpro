import { AuthService } from './../services/auth.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  isLogin;
  isAdmin;
  constructor(private authService: AuthService) {
    this.isLogin = authService.isLoggedIn();
   // console.log('authService.isLoggedIn', authService.isLoggedIn() );
    //console.log('authService.currentUser', authService.currentUser );
  }

  ngOnInit() {
    // this.isAdmin = this.authService.currentUser();
  }

}
