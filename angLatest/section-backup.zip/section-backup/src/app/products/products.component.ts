import { Observable } from 'rxjs';

import { CartService } from './../services/cart.service';
import { Product } from './../models/product';

import { ActivatedRoute } from '@angular/router';
import { Component } from '@angular/core';
import { ServerRequestService } from '../services/server-request.service';


@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.scss']
})
export class ProductsComponent  {
  products:any = [];
  filteredProducts:any = [];
  category:any;
  cartItem:any;

  constructor(private serverRequest: ServerRequestService,
  private route: ActivatedRoute, private cartService:CartService) { 

    let ItemCart = this.GetCartItem();
    ItemCart.then( quan =>{
      this.cartItem = quan;
    })

    this.serverRequest.getAll('products')
    .subscribe(res => {
      this.products = res;

     // Add  quantity Key For show product page
      for(var i=0;  i < this.products.length; i++ )
      {
        for(var a=0;  a < this.cartItem.length; a++ )
        {
          if( this.products[i]._id === this.cartItem[a].cartId )
          {
            this.products[i].quantity = this.cartItem[a].quantity;
             // console.log(this.products[i]);
          }
        
        } 
      }


      //== queryParamMap ===
      if(this.products){
        this.route.queryParamMap
        .subscribe( params => {
         // console.log('params',params);
          this.category = params.get('category');
          this.filteredProducts = (this.category)? this.products.filter(prod => prod.category === this.category)  : this.products;
          // console.log('products',this.filteredProducts);
        });
       }
    }, (error: Response) => {
      if (error.status === 404) {
         console.log('Http failure response for');
      } else {
         throw error;
      }
    });

  }

//  GetCart(id){
//   return new Promise((resolve, reject)=>{
//     this.serverRequest.getAll('carts/' + id)
//     .subscribe(res => {
//       //console.log('vohi res', res);
//       resolve(res);
//     });
//   })
// }




async GetCartItem() {
  let getItem =  await this.cartService.getCart();
  return getItem.CartProduct;
}



// for(let i=0;  i < this.products.length; i++ ){
//   let productQuan = this.GetCart(this.products[i]._id);
//   productQuan.then( quan =>{
//     this.products[i].quantity = quan[0].quantity;
//   })
// }



 

}
