import { AppError } from './../common/app.error';
import { NgForm } from '@angular/forms';
import { AuthService } from './../services/auth.service';
import { Component } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { RegexService } from '../services/regex.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent {
  Regex;
  invalidLogin: boolean;
  loginUserData = {
    email: '',
    password: ''
  };

  constructor(
    private authService: AuthService,
    private router: Router,
    private route: ActivatedRoute,
    private regexService: RegexService
    ) {

      this.Regex = {
        alpha: regexService.alphaRegex,
        email: regexService.emailRegex,
        pwd: regexService.pwdRegex,
        number: regexService.numberRegex,
        zip: regexService.zipRegex
      };



    }

  signIn(newCourse: NgForm) {

    console.log('login');

    this.authService.login('auth', this.loginUserData)
    .subscribe(res => {

      if (res) {
        console.log('error');
        newCourse.reset();
        const returnUrl = this.route.snapshot.queryParamMap.get('returnUrl');
        this.router.navigate([returnUrl || './admin']);
      } else {
        this.invalidLogin = true;
      }
    }, (error: AppError) => {
          console.log(error);
          newCourse.reset();
    });
  }




}

