export interface Product {
    title: string;
    price: number;
    category: string;
    imgUrl: string;
    quantity:number,
    _id:string
  }

