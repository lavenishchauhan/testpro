import { RegexService } from './../services/regex.service';
import { BadInput } from './../common/bad-input';
import { AppError } from './../common/app.error';
import { NgForm } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { ServerRequestService } from '../services/server-request.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit {

Regex;
registerUserData = {
  name: '',
  email: '',
  password: ''
};

constructor(private serverRequest: ServerRequestService, private regexService: RegexService) {}

  ngOnInit() {
    this.Regex = {
      alpha: this.regexService.alphaRegex,
      email: this.regexService.emailRegex,
      pwd: this.regexService.pwdRegex,
      number: this.regexService.numberRegex,
      zip: this.regexService.zipRegex
    };

  }

  // registerUser() {
  //   console.log(this.registerUserData);
  // }

  registerUser(newCourse: NgForm) {
    this.serverRequest.create('users', this.registerUserData)
    .subscribe(res => {
      if (res) {
        newCourse.reset();
      }
    }, (error: AppError) => {
      if (error instanceof BadInput) {
         console.log('400', error);
      } else {
        throw error;
      }
    });

  }


}
