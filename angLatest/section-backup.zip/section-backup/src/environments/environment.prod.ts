export const environment = {
  production: true,
  bgColor: 'blue',
  ApiUrl : 'http://localhost:3000/api/',
};
